import entities.Address;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.List;
import java.util.Scanner;

public class RemoveTowns {
    private static final String FIND_ADDRESSES = "select a from Address a where a.town.name = :tn";
    public static void main(String[] args) {
        EntityManagerFactory factory = Persistence.createEntityManagerFactory("soft_uni");
        EntityManager entityManager = factory.createEntityManager();
        Scanner scanner = new Scanner(System.in);
        String townName = scanner.nextLine();

        entityManager.getTransaction().begin();

        List<Address> addresses = entityManager.createQuery(FIND_ADDRESSES, Address.class).setParameter("tn", townName).getResultList();

        int townsToDelete = addresses.size();

        addresses.forEach(entityManager::remove);

        if(townsToDelete == 1) {
            System.out.printf("%d address in %s deleted", townsToDelete, townName);
        }else{
            System.out.printf("%d addresses in %s deleted", townsToDelete, townName);
        }

        entityManager.getTransaction().commit();
        entityManager.close();
    }
}
